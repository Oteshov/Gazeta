<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Newspaper;
use Illuminate\Http\Request;

class NewspaperController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $newspapers = Newspaper::get();
        $categories = Category::get();
        return view('admin.newspapers',[
            'newspapers'=>$newspapers,
            'categories'=>$categories,
        ]);   
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories =Category::get();

        return view('admin.newspaper_add',[
            'categories'=>$categories,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title'=>'required',
            'description'=>'required',
            'author'=>'required',
            'image'=>'mimes:jpeg,jpg,png|required|max:100000',
            'category_id'=>'required'           
        ]);

        $imageName = time().".".$request->image->getClientOriginalExtension();
        $request->image->move(public_path('/images'),$imageName);
        Newspaper::create([
            'title'=>$request->title,
            'description'=>$request->description,
            'author'=>$request->author,
            'image'=>'images/'.$imageName,
           'category_id'=>$request->category_id
        ]);
        return redirect('admin_newspapers');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $newspaper = Newspaper::find($id);

      return view('admin.newspaper_description',[
        'newspaper'=>$newspaper
      ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $newspaper = Newspaper::find($id);
        $categories = Category::get();
        return view('admin.newspaper_edit',[
            "newspaper"=>$newspaper,
            "categories"=>$categories,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(!isset($request->image))
        {
            $img_url = Newspaper::where('id',$id)->get()[0]['image'];
        }
        else
        {
            $imageName = time().".".$request->image->getClientOriginalExtension();
            $request->image->move(public_path('/images'),$imageName);
            $img_url = 'images/'.$imageName;
        }

        Newspaper::findOrFail($id)->update([
            'title'=>$request->title,
            'description'=>$request->description,
            'author'=>$request->author,
            'image'=>$img_url,
           'category_id'=>$request->category_id
        ]);
        
        return redirect('admin_newspapers');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Newspaper::destroy($id);

        return redirect('admin_newspapers');     
    }
}
