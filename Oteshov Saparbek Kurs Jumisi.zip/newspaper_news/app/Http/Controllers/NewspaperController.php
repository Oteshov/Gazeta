<?php

namespace App\Http\Controllers;

use App\Models\Newspaper;
use App\Http\Requests\StoreNewspaperRequest;
use App\Http\Requests\UpdateNewspaperRequest;
use App\Models\Category;
use GuzzleHttp\Psr7\Request;

class NewspaperController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $last_add_news = Newspaper::orderBy('created_at','DESC')->take(4)->get();
        $most_view_news = Newspaper::orderBy('count','DESC')->take(4)->get();
        $categories = Category::get();

        return view('index',[
            'last_add_news'=>$last_add_news,
            'most_view_news'=>$most_view_news,
            'categories'=>$categories
        ]);

    }

    
    public function create()
    {
        //
    }

    public function store(StoreNewspaperRequest $request)
    {
        //
    }

   
    public function show($id)
    {
        $news = Newspaper::find($id);
        $categories = Category::get();

        $update = ['count'=>$news->count+1];
        Newspaper::where('id',$news->id)->update($update);
        return view('description',[
            'news'=>$news,
            'categories'=>$categories
        ]);
    }

    
    public function edit(Newspaper $newspaper)
    {
        //
    }

    
    public function update(UpdateNewspaperRequest $request, Newspaper $newspaper)
    {
        //
    }

   
    public function destroy(Newspaper $newspaper)
    {
        //
    }
}
