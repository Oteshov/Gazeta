<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    public function login(Request $request)
    {
        $users = User::get();
        foreach($users as $user)
        {
            if($user['name'] == $request->name && $user['password'] == $request->password)
            {
                
                return view('admin.index');
                
            }
            else
            {
                return back();
            }
        }
    }

    
}
