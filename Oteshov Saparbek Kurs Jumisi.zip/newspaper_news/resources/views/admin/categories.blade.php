<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="{{url('admin')}}">Arqaga</a><br><br><br>

    <h3>Kategoriya qosiw</h3>
    <form action="{{route('admin_categories.store')}}" method="POST">
        @csrf
        <input type="text" name="name" placeholder="kategoriya" required=""><br>  
        <input type="submit"> 
    </form><br><br>
   <table border="1">
    <tr>
        <th>№</th>
        <th>ati</th>
        <th>o'zgertiw</th>
        <th>o'shiriw</th>
    </tr>
    @foreach ($categories as $category)
        <tr>
            <td>{{$loop->iteration}}</td>
            <td>{{$category->name}}</td>
            <td><a href="{{route('admin_categories.edit',$category->id)}}"><button>o'zgertiw</button></a></td>
            <td><form action="{{ route('admin_categories.destroy',$category) }}" method="POST">
                        @method('DELETE')
                        @csrf
                        <input type="submit" value="o'shiriw">
                 </form>
            </td>
        </tr>
    @endforeach
   </table>
</body>
</html>