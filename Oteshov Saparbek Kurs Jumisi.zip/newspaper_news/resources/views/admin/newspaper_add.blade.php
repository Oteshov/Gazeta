<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="{{url('admin_newspapers')}}">Arqag'a</a><br><br>

    <form action="{{route('admin_newspapers.store')}}" method="POST" enctype="multipart/form-data">
        @csrf
        <input type="text" name="title" placeholder="title" required=""><br><br>
        <textarea  placeholder="description" type="text" name="description" required=""></textarea><br><br>
         <input type="file" name="image"><br><br>
        <input type="text" name="author" placeholder="author" required=""><br><br>
        <select name="category_id" id="">
            @foreach ($categories as $category)
                <option value="{{ $category->id }}">{{ $category->name }}</option>
            @endforeach
        </select><br><br>
        <input type="submit">
    </form>
</body>
</html>