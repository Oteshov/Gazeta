<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="{{url('admin_newspapers')}}">Arqag'a</a><br><br>
<form action="{{route('admin_newspapers.update',$newspaper->id)}}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <input type="text" name="title" value="{{$newspaper->title}}" placeholder="title" required=""><br><br>
        <input type="text" name="description" value="{{$newspaper->description}}" placeholder="description" required=""><br><br> 
        <input type="text" name="author" value="{{$newspaper->author}}" placeholder="author" required=""><br><br>
        <input type="file" name="image"><br><br>
        <select name="category_id" id="" >
            @foreach ($categories as $category)
            @if($category->id == $newspaper->category_id)
            {
                <option selected value="{{ $category->id }}">{{ $category->name }}</option>
            }
            @else
            {
                <option value="{{ $category->id }}">{{ $category->name }}</option>

            }
            @endif
            @endforeach
        <input type="submit">
    </form>
</body>
</html>