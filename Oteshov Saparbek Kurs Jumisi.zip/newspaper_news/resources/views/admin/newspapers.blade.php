<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<a href="{{url('admin')}}">Arqag'a</a><br><br>
<a href="{{route('admin_newspapers.create')}}">Janaliq qosiw</a><br><br>
<table border="1">
    <tr>
        <th>№</th>
        <th>title</th>
        <th>Ko'plew oqiw</th>
        <th>Kategoriya</th>
        <th>avtor</th>
        <th>su'wret</th>
        <th>Ko'riwler sani</th>
        <th>o'zgertiw</th>
        <th>o'shiriw</th>
    </tr>
    @foreach ($newspapers as $newspaper)
        <tr>
            <td>{{$loop->iteration}}</td>
            <td>{{$newspaper->title}}</td>
            <th><a href="{{route('admin_newspapers.show',$newspaper->id)}}"><button>Ko'plew ko'riw</button></a></th>
            @foreach($categories as $category)
            @if($newspaper->category_id == $category->id)
                <td>{{ $category->name}}</td>
            @endif
            @endforeach
            <td>{{$newspaper->author}}</td>
            <td><img src="{{$newspaper->image}}" width="100px" alt="img"></td>
            <td>{{$newspaper->count}}</td>
            <td><a href="{{route('admin_newspapers.edit',$newspaper->id)}}"><button>o'zgertiw</button></a></td>
            <td><form action="{{ route('admin_newspapers.destroy',$newspaper) }}" method="POST">
                        @method('DELETE')
                        @csrf
                        <input type="submit" value="o'shiriw">
                 </form>
            </td>
        </tr>
    @endforeach
   </table>
</body>
</html>