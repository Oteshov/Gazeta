<?php

use App\Http\Controllers\Admin\CategoryController as AdminCategoryController;
use App\Http\Controllers\Admin\NewspaperController as AdminNewspaperController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\NewspaperController;
use App\Http\Controllers\RegisterController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/admin', function () {
    return view('loginn');
});

Route::get('/', function () {
    return view('index');
});
Route::post('sign_in',[RegisterController::class,'login']);   
Route::get('/',[NewspaperController::class,'index']);
Route::resource('news',NewspaperController::class);
Route::resource('categories',CategoryController::class);
Route::resource('admin_categories',AdminCategoryController::class);

Route::resource('admin_newspapers',AdminNewspaperController::class);

