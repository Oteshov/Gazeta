<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(url('admin_newspapers')); ?>">Arqag'a</a><br><br>
<form action="<?php echo e(route('admin_newspapers.update',$newspaper->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="text" name="title" value="<?php echo e($newspaper->title); ?>" placeholder="title" required=""><br><br>
        <input type="text" name="description" value="<?php echo e($newspaper->description); ?>" placeholder="description" required=""><br><br> 
        <input type="text" name="author" value="<?php echo e($newspaper->author); ?>" placeholder="author" required=""><br><br>
        <input type="file" name="image"><br><br>
        <select name="category_id" id="" >
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->id == $newspaper->category_id): ?>
            {
                <option selected value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            }
            <?php else: ?>
            {
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

            }
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <input type="submit">
    </form>
</body>
</html><?php /**PATH C:\MAMP\htdocs\newspaper_news\resources\views/admin/newspaper_edit.blade.php ENDPATH**/ ?>