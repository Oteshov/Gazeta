<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(url('admin')); ?>">Arqaga</a><br><br><br>

    <h3>Kategoriya qosiw</h3>
    <form action="<?php echo e(route('admin_categories.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="kategoriya" required=""><br>  
        <input type="submit"> 
    </form><br><br>
   <table border="1">
    <tr>
        <th>№</th>
        <th>ati</th>
        <th>o'zgertiw</th>
        <th>o'shiriw</th>
    </tr>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($category->name); ?></td>
            <td><a href="<?php echo e(route('admin_categories.edit',$category->id)); ?>"><button>o'zgertiw</button></a></td>
            <td><form action="<?php echo e(route('admin_categories.destroy',$category)); ?>" method="POST">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="o'shiriw">
                 </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
</body>
</html><?php /**PATH C:\MAMP\htdocs\newspaper_news\resources\views/admin/categories.blade.php ENDPATH**/ ?>