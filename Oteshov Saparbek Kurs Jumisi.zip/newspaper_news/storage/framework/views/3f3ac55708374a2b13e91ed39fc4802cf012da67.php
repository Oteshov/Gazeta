<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="asset/style.css">
</head>
<body>
    

	<div  align="center" class="form-container sign-in-container">
		<form action="#">
			<h1>Kiriw</h1>
			<input type="email" placeholder="Email" />
			<input type="password" placeholder="Password" />
			<button>Kiriw</button>
		</form>	
	</div>
<script src="asset/main.js"></script>
</body>
</html><?php /**PATH C:\MAMP\htdocs\newspaper_news\resources\views/login.blade.php ENDPATH**/ ?>