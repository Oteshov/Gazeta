<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Gazeta.kr</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- styles -->
  <link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/bootstrap-responsive.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/prettyPhoto.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/js/google-code-prettify/prettify.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/flexslider.css')); ?>" rel="stylesheet">

  <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/color/default.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('https://fonts.googleapis.com/css?family=Droid+Serif:400,600,400italic|Open+Sans:400,600,700')); ?>" rel="stylesheet">

  <!-- fav and touch icons -->
  <link rel="shortcut icon" href="<?php echo e(asset('assets/ico/favicon.ico')); ?>">
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('assets/ico/apple-touch-icon-144-precomposed.png')); ?>">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('assets/ico/apple-touch-icon-114-precomposed.png')); ?>">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('assets/ico/apple-touch-icon-72-precomposed.png')); ?>">
  <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('assets/ico/apple-touch-icon-57-precomposed.png')); ?>">

  <!-- =======================================================
    Theme Name: Lumia
    Theme URL: https://bootstrapmade.com/lumia-bootstrap-business-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->
</head>


<body>
  <div id="wrapper">
    <header>
      <!-- Navbar
    ================================================== -->
      <div class="navbar navbar-static-top">
        <div class="navbar-inner">
          <div class="container">
            <!-- logo -->
            <div class="logo">
              <a href="<?php echo e(route('news.index')); ?>"><h4>Gazeta.kr</h4></a>
            </div>
            <!-- end logo -->
            <!-- top menu -->
            <div class="navigation">
              <nav>
                <ul class="nav topnav">
                  <li>
                    <a href="index.html"><i class="icon-home"></i> U'y </a>
                  </li>

                  <li>
                    <a href="contact.html"><i class="icon-envelope-alt"></i> Baylanis </a>
                  </li>
                </ul>
              </nav>
            </div>
            <!-- end menu -->
          </div>
        </div>
      </div>
    </header>
    <!-- Subintro
================================================== -->
<div style="display: flex ; justify-content: center;align-items: center;  color: red;  height: 50px;">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e(route('categories.show',$category->id)); ?>"><h4 style="padding: 20px;"><?php echo e($category->name); ?> <?php echo e(" "); ?></h4></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
    <section id="maincontent">
      <div class="container">
        <div class="row">
          <div class="span12">
            <article>
              <div class="heading">
                <h4><?php echo e($news->title); ?></h4>
              </div>
              <div class="clearfix">
              </div>
              <div class="row">
                <div class="span8">
                  <!-- start flexslider -->
                  <div class="flexslider">
                    <ul class="slides1">
                      <li>
                        <img src="<?php echo e(asset($news->image)); ?>" alt="" />
                      </li>

                    </ul>
                  </div>
                  <!-- end flexslider -->
                  <p>
                    <?php echo e($news->description); ?>

                  </p>
                </div>
                <div class="span4">
                  <aside>
                    <div class="widget">
                      <div class="project-widget">
                        <h4 class="rheading">Xabar haqqinda<span></span></h4>
                        <ul class="project-detail">
                          <li><label>Avtor :</label> <?php echo e($news->author); ?></li>
                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($category->id == $news->category_id): ?>
                            <li><label>Kategoriya :</label><?php echo e($category->name); ?></li>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <li><label>Sa'ne :</label> <?php echo e($news->created_at); ?></li>
                        </ul>
                      </div>
                    </div>
                  </aside>
                </div>
              </div>
            </article>
            <!-- end article full post -->
          </div>
        </div>
      </div>
    </section>
    
    <footer class="footer">
      <div class="container">
        <div class="row">
          <div class="span4">
            <div class="widget">
              <h5>Kerekli mag'liwmatlar</h5>
              <ul class="regular">
                <li><a href="#">Sayt haqqinda</a></li>
                <li><a href="#">Biz benen baylanis</a></li>
              </ul>
            </div>
          </div>
          <div class="span4">
            <div class="widget">
              <h5>Gazeta.kr</h5>
              <div class="flickr-badge">
                <script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=9&amp;display=random&amp;size=s&amp;layout=x&amp;source=user&amp;user=34178660@N03"></script>

              </div>
              <div class="clear"></div>
            </div>
          </div>
          <div class="span4">
            <div class="widget">
              <h5>Bizdi qalay tabasiz</h5>
              <address>
								<i class="icon-home"></i> <strong>QMU</strong><br>
								Allayar Dosnazarov ko'shesi
								</address>
              <p>
                <i class="icon-phone"></i> (123) 456-7890 - (123) 555-8890<br>
                <i class="icon-envelope-alt"></i> email@domainname.com
              </p>
            </div>
            
          </div>
        </div>
      </div>
      <div class="verybottom">
        <div class="container">
          <div class="row">
            <div class="span6">
              <p>
                &copy; Gazeta.kr
              </p>
            </div>
           
            </div>
          </div>
        </div>
      </div>
    </footer>

  </div>
  <!-- end wrapper -->
  <a href="#" class="scrollup"><i class="icon-chevron-up icon-square icon-48 active"></i></a>
  <script src="<?php echo e(asset("assets/js/jquery.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/raphael-min.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/jquery.easing.1.3.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/bootstrap.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/google-code-prettify/prettify.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/jquery.elastislide.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/jquery.prettyPhoto.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/jquery.flexslider.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/jquery-hover-effect.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/portfolio/jquery.quicksand.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/portfolio/setting.js")); ?>"></script>
  <script src="<?php echo e(asset("assets/js/animate.js")); ?>"></script>

  <!-- Template Custom JavaScript File -->
  <script src="<?php echo e(asset("assets/js/custom.js")); ?>"></script>

</body>

</html>
<?php /**PATH C:\MAMP\htdocs\newspaper_news\resources\views/description.blade.php ENDPATH**/ ?>