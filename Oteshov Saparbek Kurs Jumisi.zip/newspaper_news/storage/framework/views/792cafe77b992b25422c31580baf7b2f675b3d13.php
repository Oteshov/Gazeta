<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(url('admin_categories')); ?>">Arqag'a</a><br><br>
    <form action="<?php echo e(route('admin_categories.update',$category->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="text" name="name" value="<?php echo e($category->name); ?>"> <br><br>
        <input type="submit" value="o'zgertiw">
    </form>
</body>
</html><?php /**PATH C:\MAMP\htdocs\newspaper_news\resources\views/admin/category_edit.blade.php ENDPATH**/ ?>