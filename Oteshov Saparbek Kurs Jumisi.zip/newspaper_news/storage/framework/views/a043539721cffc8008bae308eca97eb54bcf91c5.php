<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(url('admin_newspapers')); ?>">Arqag'a</a><br><br>
   <p><img src="<?php echo e(asset($newspaper->image)); ?>" width="300px" height="400" alt="img"></p><br><br>
    <p><?php echo e($newspaper->description); ?></p>
</body>
</html><?php /**PATH C:\MAMP\htdocs\newspaper_news\resources\views/admin/newspaper_description.blade.php ENDPATH**/ ?>