<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>login</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="login/css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="login/css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="login/css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="login/images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="login/css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="login/https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="login/https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body >
     
      <div id="contact" class="contact">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h3>Kiriw</h3>
                  </div>
               </div>
            </div>
            <div class="row">
             
               <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 offset-md-3">
                  <div class="contact">
                     
                     <form action="<?php echo e(url('sign_in')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                           <div class="col-sm-12">
                              <input class="contactus" placeholder="ati" type="text" name="name" required="">
                           </div>
                           <div class="col-sm-12">
                              <input class="contactus" placeholder="parol" type="password" name="password" required="">
                           </div>
                           <div class="col-sm-12">
                              <button class="send">Jiberiw</button>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
      
    
      <script src="login/js/jquery.min.js"></script> 
      <script src="login/js/popper.min.js"></script> 
      <script src="login/js/bootstrap.bundle.min.js"></script> 
      <script src="login/js/jquery-3.0.0.min.js"></script> 
      <script src="login/js/plugin.js"></script> 
      <!-- sidebar --> 
      <script src="login/js/jquery.mCustomScrollbar.concat.min.js"></script> 
      <script src="login/https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script src="login/js/custom.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         $(".zoom").hover(function(){
         
         $(this).addClass('transition');
         }, function(){
         
         $(this).removeClass('transition');
         });
         });
         
      </script> 
   </body>
</html><?php /**PATH C:\MAMP\htdocs\newspaper_news\resources\views/loginn.blade.php ENDPATH**/ ?>