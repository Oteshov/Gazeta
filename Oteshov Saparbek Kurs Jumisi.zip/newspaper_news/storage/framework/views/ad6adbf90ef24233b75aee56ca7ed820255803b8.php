<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<a href="<?php echo e(url('admin')); ?>">Arqag'a</a><br><br>
<a href="<?php echo e(route('admin_newspapers.create')); ?>">Janaliq qosiw</a><br><br>
<table border="1">
    <tr>
        <th>№</th>
        <th>title</th>
        <th>Ko'plew oqiw</th>
        <th>Kategoriya</th>
        <th>avtor</th>
        <th>su'wret</th>
        <th>Ko'riwler sani</th>
        <th>o'zgertiw</th>
        <th>o'shiriw</th>
    </tr>
    <?php $__currentLoopData = $newspapers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newspaper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($newspaper->title); ?></td>
            <th><a href="<?php echo e(route('admin_newspapers.show',$newspaper->id)); ?>"><button>Ko'plew ko'riw</button></a></th>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($newspaper->category_id == $category->id): ?>
                <td><?php echo e($category->name); ?></td>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e($newspaper->author); ?></td>
            <td><img src="<?php echo e($newspaper->image); ?>" width="100px" alt="img"></td>
            <td><?php echo e($newspaper->count); ?></td>
            <td><a href="<?php echo e(route('admin_newspapers.edit',$newspaper->id)); ?>"><button>o'zgertiw</button></a></td>
            <td><form action="<?php echo e(route('admin_newspapers.destroy',$newspaper)); ?>" method="POST">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="o'shiriw">
                 </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
</body>
</html><?php /**PATH C:\MAMP\htdocs\newspaper_news\resources\views/admin/newspapers.blade.php ENDPATH**/ ?>